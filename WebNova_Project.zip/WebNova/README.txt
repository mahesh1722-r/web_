WEBNOVA — INTERACTIVE WEB EXPERIENCE HUB
Front End Design and Testing Mini Project
Student: G. Mahesh | Register Number: 24MIC0019

HOW TO RUN
1. Extract the ZIP file.
2. Open the WebNova folder.
3. Double-click index.html, or right-click it and choose Open with a browser.
4. Use the left sidebar to browse categories and assignments.
5. Select an assignment card to open its interactive demonstration.

FILES
- index.html : website structure
- styles.css : responsive design and styling
- app.js : assignment catalogue and interactive demonstrations

TECHNOLOGIES
HTML5, CSS3 and Vanilla JavaScript. No installation or backend is required.

NOTES
The website groups the 35 distinct lab activities found in the supplied assignment PDFs. Some exercises are represented as compact demonstrations for easy navigation; use the original assignment brief when preparing a formal lab submission and verify each requirement with your faculty.
